import React from "react";

function Footer() {
  return (
    <footer>
      <div>Contact me at quejadakurt@gmail.com</div>
      <div>Philippines, manila, quezon, City</div>
      <div>9999-999-9999</div>
    </footer>
  );
}

export default Footer;
